sap.ui.define([
		'jquery.sap.global',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/json/JSONModel',
		'sap/m/QuickView'
	], function(jQuery, Controller, JSONModel) {
	"use strict";

	var BlockController = Controller.extend("com.acc.academia.controller.Block", {

		onInit: function () {
			// set explored app's demo model on this sample
			var oModel = new JSONModel(sap.ui.require.toUrl("sap/ui/demo/mock") + "/products.json");
			this.getView().setModel(oModel);
			
			var oData = {
				"items": [
					{
						"materia": "Algoritmo",
						"media": "8,77",
						"faltas": "3",
						"situacao": "APROVADO"
					},
					{
						"materia": "Matemática Discreta",
						"media": "6,59",
						"faltas": "5",
						"situacao": "REPROVADO"
					},
					{
						"materia": "Python",
						"media": "7,85",
						"faltas": "0",
						"situacao": "APROVADO"
					},
					{
						"materia": "Lógica",
						"media": "9,46",
						"faltas": "2",
						"situacao": "APROVADO"
					}]
			};
			var jsonModel = new JSONModel(oData);
			this.getView().setModel(jsonModel);                         
		},

		onSliderMoved: function (event) {
			var value = event.getParameter("value");
			this.byId("containerLayout").setWidth(value + "%");
		}
		
		
	});

	return BlockController;

});