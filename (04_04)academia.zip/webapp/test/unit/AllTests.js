sap.ui.define([
	"com/acc/academia/test/unit/controller/Block.controller"
], function () {
	"use strict";
});