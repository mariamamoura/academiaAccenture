sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/UIComponent"
], function (Controller, MessageToast, JSONModel, UIComponent) {
	"use strict";

	return Controller.extend("com.acc.academia.controller.Main", {
		onInit: function () {
			var oData = {
					"alunos":[
					{
						"nome":"Mariama Moura",
						"matricula":"12345",
						"media":"8,75",
						"situacao": "MATRICULADO"
					},
					{
						"nome":"Alexandro Júnior",
						"matricula":"12346",
						"media":"9,45",
						"situacao": "MATRICULADO"
					},
					{
						"nome":"Gustavo Pires",
						"matricula":"12375",
						"media":"6,45",
						"situacao": "TRANCADO"
					},
					{
						"nome":"Joana Silva",
						"matricula":"12305",
						"media":"7,92",
						"situacao": "MATRICULADO"
					}
					]
			};
			var jsonModel = new JSONModel(oData);
			this.getView().setModel(jsonModel);
			//this.getView().byId("myTable").

		},
		
		onPressOpenDialogAdd: function () {
			var oView = this.getView();
			var oDialog = oView.byId("add");

			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.acc.academia.view.fragment.add", this);
				oView.addDependent(oDialog);
			}

			oDialog.setEscapeHandler(function () {
				oDialog.close();
				oDialog.destroy();
			});

			oDialog.open();
		},
		
		onPressOpenDialogEdit: function () {
			var oView = this.getView();
			var oDialog = oView.byId("edit");

			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.acc.academia.view.fragment.edit", this);
				oView.addDependent(oDialog);
			}

			oDialog.setEscapeHandler(function () {
				oDialog.close();
				oDialog.destroy();
			});

			oDialog.open();
		},
		
		onPressOpenDialogDelete: function () {
			var oView = this.getView();
			var oDialog = oView.byId("delete");

			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.acc.academia.view.fragment.delete", this);
				oView.addDependent(oDialog);
			}

			oDialog.setEscapeHandler(function () {
				oDialog.close();
				oDialog.destroy();
			});

			oDialog.open();
		},
		
		onPressOpenDialogFilter: function () {
			var oView = this.getView();
			var oDialog = oView.byId("filter");

			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.acc.academia.view.fragment.filter", this);
				oView.addDependent(oDialog);
			}

			oDialog.setEscapeHandler(function () {
				oDialog.close();
				oDialog.destroy();
			});

			oDialog.open();
		},
		
		onPressCloseDialog : function() {
		    var oDialog = this.getView().byId("myDialog");
		    oDialog.close();
		    oDialog.destroy();		    
		},
		onMyDialogSelect: function() {
		    var oDialog = this.getView().byId("myDialog");
		    oDialog.close();
		    oDialog.destroy();		    
		},
		
	_showObject: function (oItem) {
				var cells = oItem.getCells();
				var objIdentfier = cells[1];
				var idVal = objIdentfier.getText();

				sap.ui.core.UIComponent.getRouterFor(this).navTo("Object", {
					id: idVal
				});
			},
			onPress: function (oEvent) {
				// The source is the list item that got pressed
				this._showObject(oEvent.getSource());
			}
	});
});