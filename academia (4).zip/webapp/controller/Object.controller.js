sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel"
], function (Controller, UIComponent) {
	"use strict";

	return Controller.extend("com.acc.academia.controller.Object", {

		onInit: function () {
			UIComponent.getRouterFor(this).getRoute("Object").attachPatternMatched(this._onObjectMatched, this);
		},
		
		_onObjectMatched : function (oEvent) {
				var id = oEvent.getParameter("arguments").id;
		},
		onBack : function(){
			UIComponent.getRouterFor(this).navTo("Inicial");
		}

	});

});