/*global QUnit*/

sap.ui.define([
	"com/acc/academia/controller/Block.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Block Controller");

	QUnit.test("I should test the Block controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});