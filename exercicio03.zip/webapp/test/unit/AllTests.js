sap.ui.define([
	"com/acc/exercicio03/test/unit/controller/Card.controller"
], function () {
	"use strict";
});