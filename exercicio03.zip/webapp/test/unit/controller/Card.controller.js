/*global QUnit*/

sap.ui.define([
	"com/acc/exercicio03/controller/Card.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Card Controller");

	QUnit.test("I should test the Card controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});