sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/UIComponent",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, MessageToast, JSONModel, UIComponent, MessageBox, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("com.acc.academia.controller.Main", {
		onInit: function () {
		//	var oModelOwnerComponent = this.getOwnerComponent().getModel("perfil");
			
			this._carregarTabela();

		},
		_refreshTable : function () {
			var oBinding = this.byId("myTable").getBinding("items");
			oBinding.refresh();
		},

		_getFiltro : function(){
			var afiltro = [];
			
			afiltro.push(new Filter("NOME", FilterOperator.Contains, "Roberto"));
			afiltro.push(new Filter("SOBRENOME", FilterOperator.Contains, "Brasil"));
			
			return new Filter({filters:afiltro, and:false});
		},
		_carregarTabela : function(){
			var sServiceUrl ="/academia/public/com/acc/Projeto1/xs/Projeto1.xsodata/";
			var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl, true);
			var that = this;
			var filtroFinal = this._getFiltro();
			oModel.read("/ALUNOS", {
					async: true,
			//		filters: [filtroFinal],
					success : function(oData, response){
						var jsonModel = new JSONModel(oData);
						that.getView().setModel(jsonModel);
						that._refreshTable();
					},
					error : function(oResponseError){
						sap.m.MessageBox.error("A quantidade de Registros exportados é muito alta." + 
								" \n\nPor favor, tente realizar um novo filtro!");
					}
				});
		},
		
		onPressOpenDialogAdd: function () {
			var oView = this.getView();
			var oDialog = oView.byId("add");

			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.acc.academia.view.fragment.add", this);
				oView.addDependent(oDialog);
			}

			oDialog.setEscapeHandler(function () {
				oDialog.close();
				oDialog.destroy();
			});

			oDialog.open();
		},
		
		onPressOpenDialogEdit: function () {
			var oView = this.getView();
			var oDialog = oView.byId("edit");

			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.acc.academia.view.fragment.edit", this);
				oView.addDependent(oDialog);
			}

			oDialog.setEscapeHandler(function () {
				oDialog.close();
				oDialog.destroy();
			});

			oDialog.open();
		},
		
		onPressOpenDialogDelete: function () {
			var oView = this.getView();
			var oDialog = oView.byId("delete");

			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.acc.academia.view.fragment.delete", this);
				oView.addDependent(oDialog);
			}

			oDialog.setEscapeHandler(function () {
				oDialog.close();
				oDialog.destroy();
			});

			oDialog.open();
		},
		
		onSalvarPerfil : function(oEvent){
			var sServiceUrl = "/academia/public/com/acc/Projeto1/xs/Projeto1.xsodata/";
			var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl, true);
			var that = this;
			
			var oDataModel = {};
            oDataModel.MATRICULA = this.getView().byId("i1").getValue();
            oDataModel.NOME = this.getView().byId("i2").getValue();
            oDataModel.SOBRENOME = this.getView().byId("i3").getValue();
            oDataModel.SITUACAO = this.getView().byId("i4").getValue();
            oDataModel.MEDIA = this.getView().byId("i5").getValue();
            
			oModel.create("/ALUNOS", oDataModel, {
					async: true,
					success : function(oData, response){
						sap.m.MessageBox.success("Aluno adicionado com sucesso!");
						that._refreshTable();
					},
					error : function(oResponseError){
						sap.m.MessageBox.error("Erro. Cheque se o número de matrícula é válido.");
					}
				});
		},
		
		onAtualizarPerfil : function(oEvent){
			var sServiceUrl = "/academia/public/com/acc/Projeto1/xs/Projeto1.xsodata/";
			var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl, true);
			var that = this;
			
			var oDataModel = {};
	        oDataModel.MATRICULA = this.getView().byId("i1").getValue();
            oDataModel.NOME = this.getView().byId("i2").getValue();
            oDataModel.SOBRENOME = this.getView().byId("i3").getValue();
            oDataModel.SITUACAO = this.getView().byId("i4").getValue();
            oDataModel.MEDIA = this.getView().byId("i5").getValue();
			
			oModel.update("/ALUNOS(" + oDataModel.MATRICULA + ")", oDataModel, {
					async: true,
				//	filters: [filtroFinal],
					success : function(oData, response){
						var jsonModel = new JSONModel(oData);
						that.getView().setModel(jsonModel);
						sap.m.MessageBox.success("Atualização realizada!");
						that._refreshTable();
					},
					error : function(oResponseError){
						sap.m.MessageBox.error("Erro. Tente novamente mais tarde");
					}
				});
		},
		
		onDeletarPerfil : function(oEvent){
			var sServiceUrl = "/academia/public/com/acc/Projeto1/xs/Projeto1.xsodata/";
			var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl, true);
			var that = this;
			
			var oDataModel = this.getView().getSelectedItems();
			
			oModel.remove("/ALUNOS(" + oDataModel + ")", oDataModel, {
					async: true,

					success : function(oData, response){
						var jsonModel = new JSONModel(oData);
						that.getView().setModel(jsonModel);
						that._refreshTable();
					},
					error : function(oResponseError){
						sap.m.MessageBox.error("A quantidade de Registros exportados é muito alta." + 
								" \n\nPor favor, tente realizar um novo filtro!");
					}
				});
		},
		onPressOpenDialog: function () {
			var oView = this.getView();
			var oDialog = oView.byId("myDialog");
			

			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.acc.academia.view.fragment.Dialog", this);
				oView.addDependent(oDialog);
			}

			oDialog.setEscapeHandler(function () {
				oDialog.close();
				oDialog.destroy();
			});

			oDialog.open();
		},
		onPressCloseDialog : function(id) {
		    var oDialog = this.getView().byId("myDialog");
		    oDialog.close();
		    oDialog.destroy();		    
		},
		onMyDialogSelect: function() {
		    var oDialog = this.getView().byId("myDialog");
		    oDialog.close();
		    oDialog.destroy();		    
		},
		_showObject: function(oItem) {
			
			var cells = oItem.getCells();
			var objIdentifier = cells[0];
			var idVal = objIdentifier.getTitle();
			
			UIComponent.getRouterFor(this).navTo("Object", {
				id: idVal
			});
		},
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},
		onEdit: function(oEvent){
			this.onPressOpenDialogEdit();
			var item = oEvent.getSource().getParent();
			var idPerfil = item.getCells()[0].getTitle();
			this.getView().byId("i1").setValue(item.getCells()[0].getTitle());
			this.getView().byId("i2").setValue(item.getCells()[1].getText());
			this.getView().byId("i3").setValue(item.getCells()[2].getText());
			this.getView().byId("i4").setValue(item.getCells()[3].getText());
			this.getView().byId("i5").setValue(item.getCells()[4].getText()); 
		}
		
/*		OnSelectionChange: function(oEvent) {

			// Store the selected item in the Object this 	
			this._item = oEvent.getSource().getBindingContext().getObject();*/
	// }
	});
});