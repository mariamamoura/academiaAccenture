function initModel() {
	var sUrl = "/academia/public/com/acc/Projeto1/xs/Projeto1.xsodata/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}