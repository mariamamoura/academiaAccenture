sap.ui.define([
	"com/acc/academia/test/unit/controller/Main.controller"
], function () {
	"use strict";
});